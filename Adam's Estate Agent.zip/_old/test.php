<?php


$txt='';


echo " david : $txt";


?>