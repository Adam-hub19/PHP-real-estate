<?php 
session_start();
include_once('admin/classess/config.php');
include_once('admin/classess/function.php');

$admin = new ADMIN(); 

if(isset($_REQUEST['action']) && $_REQUEST['action'] =='addAdminData')
    {
    $tdata=array(); 
    $tdata['username'] = $_REQUEST['username']!='' ? $_REQUEST['username'] : '';
    
    $tdata['password'] = $_REQUEST['password']!='' ? $_REQUEST['password'] : '';
    $tdata['confirm_password'] = $_REQUEST['confirm_password']!='' ? $_REQUEST['confirm_password'] : '';
    $tdata['email'] = $_REQUEST['email']!='' ? $_REQUEST['email'] : '';
    $tdata['contact_no'] = $_REQUEST['contact_no']!='' ? $_REQUEST['contact_no'] : '';
    $tdata['is_super_admin'] = 2;
   
    
    
    if($tdata['username']=='' || $tdata['password']=='' || $tdata['email']=='' || $tdata['contact_no']=='' || $tdata['is_super_admin']=='')
    {
        echo '1';
        die();
    }
	else if (!filter_var($tdata['email'], FILTER_VALIDATE_EMAIL))
     {
       echo '2'; 
       die();
     } 
    else if (!$admin->validate_mobile($tdata['contact_no']))
     {
         echo '3';die();
     }
    else if ($admin->chkMobileNumber($tdata['contact_no']))
        {
            echo '4';
            die();
        }
     else if ($admin->chkEmail($tdata['email']))
        {
            echo '5';
            die();
        } 
    else if ($tdata['password']!=$tdata['confirm_password'])
        {
            echo '6';
            die();
        }     
    else if ($admin->addCustomer($tdata)) 
        {
           echo '7';
           exit(0);
        }
    }
$recentpropertyfooter = $admin->getAllRecentPropertysFrontEnd(3);	
?>
<!DOCTYPE html>
<html >
<head>
     <?php require_once 'head.php'; ?>

</head>
<body id="top">

<div class="page_loader"></div>

<!-- main header start -->
 <?php require_once 'header.php'; ?>
<!-- main header end -->

<!-- Sub banner start -->
<div class="sub-banner overview-bgi">
    <div class="container">
        <div class="breadcrumb-area">
            
        </div>
    </div>
</div>
<!-- Sub banner end -->

<!-- properties list rightside start -->
<!-- Register page start -->
<div class="register-page">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-4 col-md-5 cnt-bg-photo d-none d-xl-block d-lg-block d-md-block" style="background-image: url(http://placehold.it/550x1050)">
                <div class="register-info">
                    <a href="index.html">
                        Tyona
                    </a>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has</p>
                </div>
            </div>
            <div class="col-lg-8 col-md-7 col-sm-12 align-self-center">
                <div class="content-form-box register-box">
                    <div class="login-header"><h4>Create Your account</h4></div>
                    <form action="#" method="GET">
                        <div class="form-group">
						    
                            <input type="text" class="form-control" id="full_name"  name="full_name" placeholder="Full Name">
                        </div>	
                        <div class="form-group">
                            <input type="number" class="form-control" id="contact_no" name="contact_no" placeholder="Mobile Number">
							<p style="color:red;" id="error3">Invalid Mobile number Format</p>
							<p style="color:red;" id="error4">Enter Another Mobile Number</p>
                        </div>
						<div class="form-group">
                            <input type="email" class="form-control" name="email" id="email" placeholder="Email Address">
							<p style="color:red;" id="error2">Invalid Email Format</p>
							<p style="color:red;" id="error5">Enter Another Email-Id</p>
                        </div>
                        <div class="form-group">
                            <input type="Password" class="form-control" name="password" id="password" placeholder="Password">
                        </div>
                        <div class="form-group">
                            <input type="Password" class="form-control" name="confirm_password" id="confirm_password" placeholder="Confirm Password">
                        </div>
						<p style="color:red;" id="error6">Your Password And Confirmation Password Do Not Match</p>
						<p style="color:red;" id="error1">Enter All The Fields</p>
					
					
					
                        <div class="form-group">
						  
                            <button type="submit" class="btn btn-color btn-md btn-block" onclick="addAdminData();">Create New Account</button>
                        </div>
                        <div class="login-footer text-center">
                            <p>Already have an account?<a href="login.php"> Sign In</a></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Register page end -->
<!-- properties list rightside end -->

<!-- Footer start -->
<?php require_once 'footer.php'; ?>
 <script>
  $(document).ready(function () {
        
         $('#error1').hide();
         $('#error2').hide();
         $('#error3').hide();
         $('#error4').hide();
         $('#error5').hide();
         $('#error6').hide();
	 });	 
    
	function addAdminData()
         {
              var username = $('#full_name').val();
			 
              var password = $('#password').val();
              var confirm_password = $('#confirm_password').val();
              var email = $('#email').val();
              var contact_no = $('#contact_no').val();
			  

              var dataString = 'email='+email+'&username='+username+'&confirm_password='+confirm_password+'&password='+password+'&contact_no='+contact_no+'&action=addAdminData'; 
              $.ajax({
                   type: "POST",
                   url: 'register.php', 
                   data: dataString,
                   cache: false,
                   success: function(result)
                        {
                           
                         if(result==1)
                         {
                             $('#error1').show();
                             $('#error2').hide();
                             $('#error3').hide();
                             $('#error4').hide();
                             $('#error5').hide();
                             $('#error6').hide();
                         }
                         else if(result==2)
                         {
                             $('#error1').hide();
                             $('#error2').show();
                             $('#error3').hide();
                             $('#error4').hide();
                             $('#error5').hide();
                             $('#error6').hide();
                         }
                         else if(result==3)
                         {
                             $('#error1').hide();
                             $('#error2').hide();
                             $('#error3').show();
                             $('#error4').hide();
                             $('#error5').hide();
                             $('#error6').hide();
                         }
                         else if(result==4)
                         {
                             $('#error1').hide();
                             $('#error2').hide();
                             $('#error3').hide();
                             $('#error4').show();
                             $('#error5').hide();
                             $('#error6').hide();
                         }
                         else if(result==5)
                         {
                             $('#error1').hide();
                             $('#error2').hide();
                             $('#error3').hide();
                             $('#error4').hide();
                             $('#error5').show();
                             $('#error6').hide();
                         }
                         else if(result==6)
                         {
                             $('#error1').hide();
                             $('#error2').hide();
                             $('#error3').hide();
                             $('#error4').hide();
                             $('#error5').hide();
                             $('#error6').show();
                         }
                         else  if(result==7)
                         {
                             alert('Sign Up Successfully');
                             window.location.href = "login.php";
                         }
                         else
                         {
                              alert(result);
                         }
                        }
              });

         }
        </script>


</body>
</html>