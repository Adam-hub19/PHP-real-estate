<html>
<head>
    <?php include_once 'head.php';?>
    <link rel="stylesheet" type="text/css" href="css/logincss.css">
    <link rel="stylesheet" type="text/css" href="../scss/login.scss">
    <meta charset="utf-8" />
   <title>Login</title>
   <meta content="width=device-width, initial-scale=1.0" name="viewport" />
   <meta content="" name="description" />
   <meta content="" name="author" />
       
</head>
<body>

    <form method="POST" id="loginform">
        <div class="login-form">
        
  
        <div class="form-group ">
            <input type="text" class="form-control" placeholder="Email-Id" id="email" name="email">
            <i class="fa fa-user"></i>
           </div>
       <div class="form-group">
           <input type="password" class="form-control" placeholder="Password" id="password" name="password">
            <i class="fa fa-lock"></i>
            </div>
<!--        <span class="alert">Invalid Credentials</span>-->
       
        <button type="button" class="log-btn" name="sub" onclick="loginproceeds();return false;">Log in</button>
        </div>
    </form>
<script src="js/jquery-1.8.2.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap-dialog.js"></script>
<script src="js/index.js"></script> 
<script src="validation/login.js"></script>  

</body>

</html>
