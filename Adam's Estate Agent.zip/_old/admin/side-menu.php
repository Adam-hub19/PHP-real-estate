<aside id="hoe-left-panel" hoe-position-type="absolute">
                      
                    <ul class="nav panel-list">
                      
                        <li class="<?php if($page_id == 1) { echo 'active'; } ?>">
                            <a href="index.php">
                                <i class="fa fa-home"></i>
                                <span class="menu-text">Dashboard</span>
                                <span class="selected"></span>
                            </a>
                        </li>
                        
                        <li>
                            <a href="manage-property.php">
                                <i class="fa fa-building"></i>
                                <span class="menu-text">Manage Property</span>
                                <span class="selected"></span>
                            </a>
                        </li>
                        <li>
                            <a href="manage-blog.php">
                                <i class="fa fa-male"></i>
                                <span class="menu-text">Manage Blog</span>
                                <span class="selected"></span>
                            </a>
                        </li>
                       
					   <li>
                            <a href="manage-testinomial.php">
                                <i class="fa fa-male"></i>
                                <span class="menu-text">Manage Testinomial</span>
                                <span class="selected"></span>
                            </a>
                        </li>
						
						<li>
                            <a href="manage-agent.php">
                                <i class="fa fa-male"></i>
                                <span class="menu-text">Manage Agent</span>
                                <span class="selected"></span>
                            </a>
                        </li>
                       </ul>
                      
                </aside><!--aside left menu end-->