<!--footer start-->
<div class="footer">
    <div class="row">
        <div class="col-sm-12">
            <span>© 2019 All rights reserved. Template designed by Qwertech.</span>
        </div>
    </div>
</div>
<!--footer end-->